
for l = 1:length(data)
    for i = 1:length(data(1).x_current)
    
    req = requiredForces(data(l).x_current(i),   data(l).x_desired(i),   data(l).x_velocity_current(i),   data(l).x_velocity_desired(i),...
                         data(l).y_current(i),   data(l).y_desired(i),   data(l).y_velocity_current(i),   data(l).y_velocity_desired(i),...
                         data(l).yaw_current(i), data(l).yaw_desired(i), data(l).yaw_velocity_current(i), data(l).yaw_velocity_desired(i), pdGain);
                        
    ForceX(i)  = req.ForceX;
    ForceY(i)  = req.ForceY;
    MomentZ(i) = req.MomentZ;
    
    
    end
    
    required(l).ForceX = ForceX;
    required(l).ForceY = ForceY;
    required(l).MomentZ = MomentZ;

    figure()
    plot(required(l).ForceX)
    title('X Force Required')
    hold on
    plot(data(l).required_force_x,'r')

    figure()
    plot(required(l).ForceY)
    title('Y Force Required')
    hold on
    plot(data(l).required_force_y,'r')

    figure()
    plot(required(l).MomentZ)
    title('Moment Required')
    hold on
    plot(data(l).required_moment_z,'r')

end
                        
                        
