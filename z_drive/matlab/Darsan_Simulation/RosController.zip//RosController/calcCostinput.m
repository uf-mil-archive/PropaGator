current = [0; 0; 0; 0];
guess = [-1.22; -23.5;1.22; 39.25];

Fxref = 0;
Fyref = 1000;
Mref = 0;

